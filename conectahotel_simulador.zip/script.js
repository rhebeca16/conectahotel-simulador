
function calcular() {
    const area = parseFloat(document.getElementById("area").value);
    const estrutura = document.getElementById("estrutura").value;
    let fator = 1;

    switch (estrutura) {
        case "leve":
            fator = 60;
            break;
        case "media":
            fator = 40;
            break;
        case "pesada":
            fator = 30;
            break;
    }

    if (isNaN(area) || area <= 0) {
        document.getElementById("resultado").innerText = "Por favor, insira uma área válida.";
        return;
    }

    const qtd = Math.ceil(area / fator);
    document.getElementById("resultado").innerText = `Quantidade estimada de roteadores Mesh: ${qtd}`;
}
